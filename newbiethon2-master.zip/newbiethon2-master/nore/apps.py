from django.apps import AppConfig


class NoreConfig(AppConfig):
    name = 'nore'
